import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { Toaster } from '@/components/ui/toaster';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import Header from '@/components/layout/Header';
import Dashboard from '@/pages/Dashboard';
import BookingManager from '@/components/BookingManager';
import PaymentManager from '@/components/PaymentManager';
import ExpenseManager from '@/components/ExpenseManager';
import SettingsManager from '@/components/SettingsManager';
import HotelManager from '@/components/HotelManager';
import { Sidebar } from '@/components/Sidebar';
import './App.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <ProtectedRoute>
            <div className="flex h-screen bg-gray-100">
              <Sidebar />
              <div className="flex-1 flex flex-col overflow-hidden">
                <Header />
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/bookings" element={<BookingManager />} />
                    <Route path="/payments" element={<PaymentManager />} />
                    <Route path="/expenses" element={<ExpenseManager />} />
                    <Route path="/hotels" element={<HotelManager />} />
                    <Route path="/settings" element={<SettingsManager />} />
                  </Routes>
                </main>
              </div>
            </div>
          </ProtectedRoute>
          <Toaster />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;