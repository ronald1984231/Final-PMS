import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calendar, 
  DollarSign, 
  Users, 
  TrendingUp, 
  AlertCircle,
  Hotel,
  CreditCard,
  Receipt,
  Building,
  Settings
} from 'lucide-react';
import BookingManager from '@/components/BookingManager';
import PaymentManager from '@/components/PaymentManager';
import ExpenseManager from '@/components/ExpenseManager';
import HotelManager from '@/components/HotelManager';
import SettingsManager from '@/components/SettingsManager';
import HotelSelector from '@/components/HotelSelector';
import { DashboardStats } from '@/lib/types';
import { calculateDashboardStats, formatCurrency, formatDate } from '@/lib/utils-pms';
import { initializeSampleData } from '@/lib/storage';
import { initializeHotelData, getCurrentHotel } from '@/lib/hotel-storage';

const Index: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalBookings: 0,
    totalRevenue: 0,
    pendingPayments: 0,
    monthlyExpenses: 0,
    occupancyRate: 0,
    recentBookings: [],
    recentPayments: [],
    recentExpenses: []
  });
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentHotel, setCurrentHotel] = useState(getCurrentHotel());

  useEffect(() => {
    // Initialize hotel and sample data if needed
    initializeHotelData();
    initializeSampleData();
    loadStats();
    setCurrentHotel(getCurrentHotel());
  }, []);

  const loadStats = () => {
    setStats(calculateDashboardStats());
  };

  const handleHotelChange = () => {
    // Refresh data when hotel changes
    setCurrentHotel(getCurrentHotel());
    loadStats();
    // Force re-render of all components by updating a key or state
    window.location.reload(); // Simple approach to refresh all data
  };

  const handleAddHotel = () => {
    setActiveTab('hotels');
  };

  const StatCard: React.FC<{
    title: string;
    value: string;
    icon: React.ReactNode;
    trend?: string;
    trendUp?: boolean;
  }> = ({ title, value, icon, trend, trendUp }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {trend && (
          <p className={`text-xs ${trendUp ? 'text-green-600' : 'text-red-600'}`}>
            {trendUp ? '+' : '-'}{trend} from last month
          </p>
        )}
      </CardContent>
    </Card>
  );

  // Show hotel selection if no current hotel
  if (!currentHotel) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto p-6">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-6">Hotel PMS</h1>
            
            {/* Hotel Selector */}
            <HotelSelector onHotelChange={handleHotelChange} onAddHotel={handleAddHotel} />
          </div>

          <Card className="w-full max-w-md mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Welcome to Hotel PMS
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                No hotel is currently selected. Please add a hotel to get started.
              </p>
              <Button 
                onClick={() => setActiveTab('hotels')} 
                className="w-full"
              >
                <Building className="h-4 w-4 mr-2" />
                Add Your First Hotel
              </Button>
            </CardContent>
          </Card>

          {/* Show hotel management tab */}
          <div className="mt-8">
            <Tabs value="hotels" className="space-y-6">
              <TabsContent value="hotels">
                <HotelManager />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Hotel PMS</h1>
          
          {/* Hotel Selector */}
          <HotelSelector onHotelChange={handleHotelChange} onAddHotel={handleAddHotel} />
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="bookings" className="flex items-center gap-2">
              <Hotel className="h-4 w-4" />
              Bookings
            </TabsTrigger>
            <TabsTrigger value="payments" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="expenses" className="flex items-center gap-2">
              <Receipt className="h-4 w-4" />
              Expenses
            </TabsTrigger>
            <TabsTrigger value="hotels" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              Hotels
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <StatCard
                title="Total Bookings"
                value={stats.totalBookings.toString()}
                icon={<Calendar className="h-4 w-4 text-muted-foreground" />}
                trend="12%"
                trendUp={true}
              />
              <StatCard
                title="Revenue (Month)"
                value={formatCurrency(stats.totalRevenue)}
                icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
                trend="8%"
                trendUp={true}
              />
              <StatCard
                title="Pending Payments"
                value={formatCurrency(stats.pendingPayments)}
                icon={<AlertCircle className="h-4 w-4 text-muted-foreground" />}
              />
              <StatCard
                title="Occupancy Rate"
                value={`${stats.occupancyRate.toFixed(1)}%`}
                icon={<Users className="h-4 w-4 text-muted-foreground" />}
                trend="5%"
                trendUp={true}
              />
            </div>

            {/* Recent Activities */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {/* Recent Bookings */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Bookings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {stats.recentBookings.length > 0 ? (
                    stats.recentBookings.map((booking) => (
                      <div key={booking.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{booking.guestName}</p>
                          <p className="text-sm text-muted-foreground">
                            Room {booking.roomNumber} • {formatDate(booking.checkInDate)}
                          </p>
                        </div>
                        <Badge variant={booking.status === 'confirmed' ? 'default' : 'outline'}>
                          {booking.status}
                        </Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No recent bookings</p>
                  )}
                </CardContent>
              </Card>

              {/* Recent Payments */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Payments</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {stats.recentPayments.length > 0 ? (
                    stats.recentPayments.map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{formatCurrency(payment.amount)}</p>
                          <p className="text-sm text-muted-foreground">
                            {payment.paymentMethod.replace('-', ' ').toUpperCase()} • {formatDate(payment.paymentDate)}
                          </p>
                        </div>
                        <Badge variant={payment.status === 'completed' ? 'default' : 'outline'}>
                          {payment.status}
                        </Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No recent payments</p>
                  )}
                </CardContent>
              </Card>

              {/* Recent Expenses */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Expenses</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {stats.recentExpenses.length > 0 ? (
                    stats.recentExpenses.map((expense) => (
                      <div key={expense.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{expense.description}</p>
                          <p className="text-sm text-muted-foreground">
                            {expense.category.replace('_', ' ').toUpperCase()} • {formatDate(expense.date)}
                          </p>
                        </div>
                        <p className="font-medium text-red-600">
                          -{formatCurrency(expense.amount)}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No recent expenses</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Monthly Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Monthly Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">
                      {formatCurrency(stats.totalRevenue)}
                    </p>
                    <p className="text-sm text-muted-foreground">Total Revenue</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-red-600">
                      {formatCurrency(stats.monthlyExpenses)}
                    </p>
                    <p className="text-sm text-muted-foreground">Total Expenses</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">
                      {formatCurrency(stats.totalRevenue - stats.monthlyExpenses)}
                    </p>
                    <p className="text-sm text-muted-foreground">Net Profit</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-4">
                  <Button onClick={() => setActiveTab('bookings')}>
                    <Hotel className="h-4 w-4 mr-2" />
                    New Booking
                  </Button>
                  <Button variant="outline" onClick={() => setActiveTab('payments')}>
                    <CreditCard className="h-4 w-4 mr-2" />
                    Record Payment
                  </Button>
                  <Button variant="outline" onClick={() => setActiveTab('expenses')}>
                    <Receipt className="h-4 w-4 mr-2" />
                    Add Expense
                  </Button>
                  <Button variant="outline" onClick={loadStats}>
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Refresh Data
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other Tabs */}
          <TabsContent value="bookings">
            <BookingManager key={currentHotel?.id} />
          </TabsContent>

          <TabsContent value="payments">
            <PaymentManager key={currentHotel?.id} />
          </TabsContent>

          <TabsContent value="expenses">
            <ExpenseManager key={currentHotel?.id} />
          </TabsContent>

          <TabsContent value="hotels">
            <HotelManager />
          </TabsContent>

          <TabsContent value="settings">
            <SettingsManager />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Index;