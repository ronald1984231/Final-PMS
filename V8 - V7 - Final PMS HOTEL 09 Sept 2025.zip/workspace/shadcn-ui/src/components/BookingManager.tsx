import React, { useState, useEffect } from 'react';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Edit, Trash2, Upload, Plus, X } from 'lucide-react';
import { Booking, BookingStatus, BookingPayment, PaymentAccount } from '@/lib/types';
import { bookingStorage } from '@/lib/storage';
import { generateId, formatCurrency, formatDate, validateBooking, calculateBookingBalance, getBookingPaymentStatus } from '@/lib/utils-pms';
import ImportDialog from './ImportDialog';
import { importBookings, SAMPLE_BOOKING_DATA } from '@/lib/import-utils';
import { getCurrentHotel } from '@/lib/hotel-storage';

const BookingManager: React.FC = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [paymentAccounts, setPaymentAccounts] = useState<PaymentAccount[]>([]);
  const [formData, setFormData] = useState<Partial<Booking>>({
    guestName: '',
    email: '',
    phone: '',
    roomNumber: '',
    roomType: 'Standard',
    checkInDate: '',
    checkOutDate: '',
    totalAmount: 0,
    status: BookingStatus.PENDING,
    notes: '',
    payments: []
  });
  const [errors, setErrors] = useState<string[]>([]);

  useEffect(() => {
    loadBookings();
    loadPaymentAccounts();
  }, []);

  const loadBookings = () => {
    setBookings(bookingStorage.getAll());
  };

  const loadPaymentAccounts = () => {
    const currentHotel = getCurrentHotel();
    if (currentHotel && currentHotel.paymentAccounts) {
      setPaymentAccounts(currentHotel.paymentAccounts);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationErrors = validateBooking(formData);
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    const now = new Date().toISOString();
    const booking: Booking = {
      id: editingBooking?.id || generateId(),
      hotelId: '', // Will be set by storage
      guestName: formData.guestName!,
      email: formData.email!,
      phone: formData.phone!,
      roomNumber: formData.roomNumber!,
      roomType: formData.roomType!,
      checkInDate: formData.checkInDate!,
      checkOutDate: formData.checkOutDate!,
      totalAmount: formData.totalAmount!,
      status: formData.status!,
      notes: formData.notes || '',
      createdAt: editingBooking?.createdAt || now,
      updatedAt: now,
      payments: formData.payments || []
    };

    bookingStorage.save(booking);
    loadBookings();
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      guestName: '',
      email: '',
      phone: '',
      roomNumber: '',
      roomType: 'Standard',
      checkInDate: '',
      checkOutDate: '',
      totalAmount: 0,
      status: BookingStatus.PENDING,
      notes: '',
      payments: []
    });
    setEditingBooking(null);
    setErrors([]);
    setIsDialogOpen(false);
  };

  const handleEdit = (booking: Booking) => {
    setFormData(booking);
    setEditingBooking(booking);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this booking?')) {
      bookingStorage.delete(id);
      loadBookings();
    }
  };

  const handleImport = async (data: Record<string, string>[]) => {
    const result = await importBookings(data);
    loadBookings(); // Refresh the list
    setIsImportDialogOpen(false);
    return result;
  };

  const addPayment = () => {
    const newPayment: BookingPayment = {
      id: generateId(),
      amount: 0,
      paymentDate: new Date().toISOString().split('T')[0],
      paymentAccountId: paymentAccounts[0]?.id || '',
      notes: ''
    };
    setFormData(prev => ({
      ...prev,
      payments: [...(prev.payments || []), newPayment]
    }));
  };

  const removePayment = (index: number) => {
    setFormData(prev => ({
      ...prev,
      payments: (prev.payments || []).filter((_, i) => i !== index)
    }));
  };

  const updatePayment = (index: number, field: keyof BookingPayment, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      payments: (prev.payments || []).map((payment, i) => 
        i === index ? { ...payment, [field]: value } : payment
      )
    }));
  };

  const getTotalPayments = () => {
    return (formData.payments || []).reduce((sum, payment) => sum + payment.amount, 0);
  };

  const getPaymentAccountName = (accountId: string) => {
    const account = paymentAccounts.find(acc => acc.id === accountId);
    return account?.name || 'Unknown Account';
  };

  const getStatusBadge = (status: BookingStatus) => {
    const variants: Record<BookingStatus, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      [BookingStatus.PENDING]: 'outline',
      [BookingStatus.CONFIRMED]: 'default',
      [BookingStatus.CHECKED_IN]: 'secondary',
      [BookingStatus.CHECKED_OUT]: 'secondary',
      [BookingStatus.CANCELLED]: 'destructive'
    };
    
    return <Badge variant={variants[status]}>{status}</Badge>;
  };

  const getPaymentStatusBadge = (booking: Booking) => {
    const status = getBookingPaymentStatus(booking);
    const balance = calculateBookingBalance(booking);
    
    const variants: Record<string, 'default' | 'outline' | 'destructive'> = {
      paid: 'default',
      partial: 'outline',
      unpaid: 'destructive'
    };
    
    return (
      <div className="flex flex-col">
        <Badge variant={variants[status]}>
          {status === 'paid' ? 'Paid' : status === 'partial' ? 'Partial' : 'Unpaid'}
        </Badge>
        {balance > 0 && (
          <span className="text-xs text-muted-foreground mt-1">
            Balance: {formatCurrency(balance)}
          </span>
        )}
      </div>
    );
  };

  const columns = [
    {
      key: 'guestName',
      header: 'Guest Name',
      render: (booking: Booking) => (
        <div>
          <div className="font-medium">{booking.guestName}</div>
          <div className="text-sm text-muted-foreground">{booking.email}</div>
        </div>
      )
    },
    {
      key: 'roomNumber',
      header: 'Room',
      render: (booking: Booking) => (
        <div>
          <div className="font-medium">{booking.roomNumber}</div>
          <div className="text-sm text-muted-foreground">{booking.roomType}</div>
        </div>
      )
    },
    {
      key: 'checkInDate',
      header: 'Check-in',
      render: (booking: Booking) => formatDate(booking.checkInDate)
    },
    {
      key: 'checkOutDate',
      header: 'Check-out',
      render: (booking: Booking) => formatDate(booking.checkOutDate)
    },
    {
      key: 'totalAmount',
      header: 'Amount',
      render: (booking: Booking) => formatCurrency(booking.totalAmount)
    },
    {
      key: 'status',
      header: 'Status',
      render: (booking: Booking) => getStatusBadge(booking.status)
    },
    {
      key: 'payment',
      header: 'Payment',
      render: (booking: Booking) => getPaymentStatusBadge(booking),
      sortable: false
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (booking: Booking) => (
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleEdit(booking)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleDelete(booking.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
      sortable: false
    }
  ];

  return (
    <div className="space-y-6">
      <DataTable
        data={bookings}
        columns={columns}
        searchKey="guestName"
        title="Bookings"
        onAdd={() => setIsDialogOpen(true)}
        addButtonText="New Booking"
        extraActions={
          <Button variant="outline" onClick={() => setIsImportDialogOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Import CSV
          </Button>
        }
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingBooking ? 'Edit Booking' : 'New Booking'}
            </DialogTitle>
          </DialogHeader>

          {errors.length > 0 && (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <ul className="text-sm text-destructive space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="guestName">Guest Name *</Label>
                <Input
                  id="guestName"
                  value={formData.guestName}
                  onChange={(e) => setFormData(prev => ({ ...prev, guestName: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="roomNumber">Room Number *</Label>
                <Input
                  id="roomNumber"
                  value={formData.roomNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, roomNumber: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="roomType">Room Type</Label>
                <Select
                  value={formData.roomType}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, roomType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Standard">Standard</SelectItem>
                    <SelectItem value="Deluxe">Deluxe</SelectItem>
                    <SelectItem value="Suite">Suite</SelectItem>
                    <SelectItem value="Presidential">Presidential</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, status: value as BookingStatus }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.values(BookingStatus).map(status => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="checkInDate">Check-in Date *</Label>
                <Input
                  id="checkInDate"
                  type="date"
                  value={formData.checkInDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, checkInDate: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="checkOutDate">Check-out Date *</Label>
                <Input
                  id="checkOutDate"
                  type="date"
                  value={formData.checkOutDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, checkOutDate: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="totalAmount">Total Amount *</Label>
                <Input
                  id="totalAmount"
                  type="number"
                  step="0.01"
                  value={formData.totalAmount}
                  onChange={(e) => setFormData(prev => ({ ...prev, totalAmount: parseFloat(e.target.value) || 0 }))}
                />
              </div>
            </div>

            {/* Payments Section */}
            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Payments</h3>
                <Button type="button" onClick={addPayment} variant="outline" size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Payment
                </Button>
              </div>

              {(formData.payments || []).map((payment, index) => (
                <div key={payment.id} className="grid grid-cols-5 gap-2 items-end mb-2 p-3 border rounded">
                  <div>
                    <Label>Amount</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={payment.amount}
                      onChange={(e) => updatePayment(index, 'amount', parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                    />
                  </div>
                  <div>
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={payment.paymentDate}
                      onChange={(e) => updatePayment(index, 'paymentDate', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Payment Account</Label>
                    <Select 
                      value={payment.paymentAccountId} 
                      onValueChange={(value) => updatePayment(index, 'paymentAccountId', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select account" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentAccounts.map((account) => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Notes</Label>
                    <Input
                      value={payment.notes || ''}
                      onChange={(e) => updatePayment(index, 'notes', e.target.value)}
                      placeholder="Optional notes"
                    />
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removePayment(index)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}

              {(formData.payments || []).length > 0 && (
                <div className="mt-4 p-3 bg-gray-50 rounded">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Total Payments:</span>
                    <span className="font-bold">${getTotalPayments().toFixed(2)}</span>
                  </div>
                  {formData.totalAmount && (
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-sm text-gray-600">Remaining Balance:</span>
                      <span className={`text-sm font-medium ${
                        (formData.totalAmount - getTotalPayments()) > 0 ? 'text-red-600' : 'text-green-600'
                      }`}>
                        ${(formData.totalAmount - getTotalPayments()).toFixed(2)}
                      </span>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={resetForm}>
                Cancel
              </Button>
              <Button type="submit">
                {editingBooking ? 'Update' : 'Create'} Booking
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ImportDialog
        isOpen={isImportDialogOpen}
        onClose={() => setIsImportDialogOpen(false)}
        onImport={handleImport}
        type="bookings"
        sampleData={SAMPLE_BOOKING_DATA}
      />
    </div>
  );
};

export default BookingManager;