import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Building, Plus } from 'lucide-react';
import { Hotel } from '@/lib/types';
import { hotelStorage, getCurrentHotel, setCurrentHotel } from '@/lib/hotel-storage';

interface HotelSelectorProps {
  onHotelChange?: () => void;
  onAddHotel?: () => void;
}

const HotelSelector: React.FC<HotelSelectorProps> = ({ onHotelChange, onAddHotel }) => {
  const hotels = hotelStorage.getAll();
  const currentHotel = getCurrentHotel();

  const handleHotelChange = (hotelId: string) => {
    const selectedHotel = hotels.find(h => h.id === hotelId);
    if (selectedHotel) {
      setCurrentHotel(selectedHotel.id);
      onHotelChange?.();
    }
  };

  if (hotels.length === 0) {
    return (
      <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg border">
        <Building className="h-5 w-5 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">No hotels available</span>
        <Button size="sm" onClick={onAddHotel}>
          <Plus className="h-4 w-4 mr-1" />
          Add Hotel
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg border">
      <Building className="h-5 w-5 text-muted-foreground" />
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-muted-foreground">Hotel:</span>
        <Select
          value={currentHotel?.id || ''}
          onValueChange={handleHotelChange}
        >
          <SelectTrigger className="w-[250px] bg-background">
            <SelectValue placeholder="Select a hotel" />
          </SelectTrigger>
          <SelectContent>
            {hotels.map((hotel) => (
              <SelectItem key={hotel.id} value={hotel.id}>
                <div className="flex items-center justify-between w-full">
                  <span>{hotel.name}</span>
                  <Badge variant="outline" className="ml-2 text-xs">
                    {hotel.currency}
                  </Badge>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {currentHotel && (
        <div className="flex items-center gap-2 ml-auto">
          <Badge variant="secondary">
            {currentHotel.totalRooms} rooms
          </Badge>
          <Badge variant="outline">
            {currentHotel.city}, {currentHotel.country}
          </Badge>
        </div>
      )}
      
      <Button size="sm" variant="outline" onClick={onAddHotel}>
        <Plus className="h-4 w-4 mr-1" />
        Add Hotel
      </Button>
    </div>
  );
};

export default HotelSelector;