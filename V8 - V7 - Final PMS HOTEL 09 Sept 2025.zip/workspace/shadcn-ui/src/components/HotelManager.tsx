import React, { useState, useEffect } from 'react';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Edit, Trash2, Building, CheckCircle } from 'lucide-react';
import { Hotel } from '@/lib/types';
import { hotelStorage, settingsStorage, getCurrentHotel } from '@/lib/hotel-storage';
import { generateId, validateHotel } from '@/lib/utils-pms';
import { CURRENCIES, TIMEZONES } from '@/lib/types';

const HotelManager: React.FC = () => {
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [currentHotel, setCurrentHotel] = useState<Hotel | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingHotel, setEditingHotel] = useState<Hotel | null>(null);
  const [formData, setFormData] = useState<Partial<Hotel>>({
    name: '',
    address: '',
    phone: '',
    email: '',
    totalRooms: 50,
    currency: 'USD',
    timezone: 'America/New_York'
  });
  const [errors, setErrors] = useState<string[]>([]);

  useEffect(() => {
    loadHotels();
    setCurrentHotel(getCurrentHotel());
  }, []);

  const loadHotels = () => {
    setHotels(hotelStorage.getAll());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationErrors = validateHotel(formData);
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    const now = new Date().toISOString();
    const hotel: Hotel = {
      id: editingHotel?.id || generateId(),
      name: formData.name!,
      address: formData.address!,
      phone: formData.phone!,
      email: formData.email!,
      totalRooms: formData.totalRooms!,
      currency: formData.currency!,
      timezone: formData.timezone!,
      createdAt: editingHotel?.createdAt || now,
      updatedAt: now
    };

    hotelStorage.save(hotel);
    
    // If this is the first hotel or no current hotel is set, make it current
    if (!currentHotel || hotels.length === 0) {
      settingsStorage.updateCurrentHotel(hotel.id);
      setCurrentHotel(hotel);
    }
    
    loadHotels();
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      name: '',
      address: '',
      phone: '',
      email: '',
      totalRooms: 50,
      currency: 'USD',
      timezone: 'America/New_York'
    });
    setEditingHotel(null);
    setErrors([]);
    setIsDialogOpen(false);
  };

  const handleEdit = (hotel: Hotel) => {
    setFormData(hotel);
    setEditingHotel(hotel);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (currentHotel?.id === id) {
      alert('Cannot delete the currently active hotel. Please switch to another hotel first.');
      return;
    }
    
    if (confirm('Are you sure you want to delete this hotel? This will also delete all associated bookings, payments, and expenses.')) {
      hotelStorage.delete(id);
      loadHotels();
    }
  };

  const handleSetCurrent = (hotel: Hotel) => {
    settingsStorage.updateCurrentHotel(hotel.id);
    setCurrentHotel(hotel);
    // Reload the page to refresh all data for the new hotel
    window.location.reload();
  };

  const columns = [
    {
      key: 'name',
      header: 'Hotel Name',
      render: (hotel: Hotel) => (
        <div className="flex items-center gap-2">
          <Building className="h-4 w-4 text-muted-foreground" />
          <div>
            <div className="font-medium">{hotel.name}</div>
            <div className="text-sm text-muted-foreground">{hotel.email}</div>
          </div>
          {currentHotel?.id === hotel.id && (
            <CheckCircle className="h-4 w-4 text-green-600" />
          )}
        </div>
      )
    },
    {
      key: 'address',
      header: 'Address',
      render: (hotel: Hotel) => (
        <div className="max-w-xs">
          <div className="text-sm">{hotel.address}</div>
          <div className="text-sm text-muted-foreground">{hotel.phone}</div>
        </div>
      )
    },
    {
      key: 'totalRooms',
      header: 'Rooms',
      render: (hotel: Hotel) => (
        <Badge variant="outline">{hotel.totalRooms} rooms</Badge>
      )
    },
    {
      key: 'currency',
      header: 'Currency',
      render: (hotel: Hotel) => (
        <Badge variant="secondary">{hotel.currency}</Badge>
      )
    },
    {
      key: 'timezone',
      header: 'Timezone',
      render: (hotel: Hotel) => (
        <div className="text-sm">{hotel.timezone}</div>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (hotel: Hotel) => (
        <div className="flex space-x-2">
          {currentHotel?.id !== hotel.id && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleSetCurrent(hotel)}
            >
              Set Active
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleEdit(hotel)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleDelete(hotel.id)}
            disabled={currentHotel?.id === hotel.id}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
      sortable: false
    }
  ];

  return (
    <div className="space-y-6">
      {currentHotel && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Current Hotel: {currentHotel.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <span className="font-medium">Address:</span>
                <div className="text-muted-foreground">{currentHotel.address}</div>
              </div>
              <div>
                <span className="font-medium">Contact:</span>
                <div className="text-muted-foreground">{currentHotel.phone}</div>
              </div>
              <div>
                <span className="font-medium">Currency:</span>
                <div className="text-muted-foreground">{currentHotel.currency}</div>
              </div>
              <div>
                <span className="font-medium">Timezone:</span>
                <div className="text-muted-foreground">{currentHotel.timezone}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <DataTable
        data={hotels}
        columns={columns}
        searchKey="name"
        title="Hotels"
        onAdd={() => setIsDialogOpen(true)}
        addButtonText="Add Hotel"
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingHotel ? 'Edit Hotel' : 'Add New Hotel'}
            </DialogTitle>
          </DialogHeader>

          {errors.length > 0 && (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <ul className="text-sm text-destructive space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Hotel Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="address">Address *</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                rows={2}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="phone">Phone *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="totalRooms">Total Rooms *</Label>
                <Input
                  id="totalRooms"
                  type="number"
                  min="1"
                  value={formData.totalRooms}
                  onChange={(e) => setFormData(prev => ({ ...prev, totalRooms: parseInt(e.target.value) || 1 }))}
                />
              </div>
              <div>
                <Label htmlFor="currency">Currency</Label>
                <Select
                  value={formData.currency}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, currency: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CURRENCIES.map(currency => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.symbol} {currency.name} ({currency.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="timezone">Timezone</Label>
              <Select
                value={formData.timezone}
                onValueChange={(value) => setFormData(prev => ({ ...prev, timezone: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIMEZONES.map(tz => (
                    <SelectItem key={tz.value} value={tz.value}>
                      {tz.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={resetForm}>
                Cancel
              </Button>
              <Button type="submit">
                {editingHotel ? 'Update' : 'Create'} Hotel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default HotelManager;