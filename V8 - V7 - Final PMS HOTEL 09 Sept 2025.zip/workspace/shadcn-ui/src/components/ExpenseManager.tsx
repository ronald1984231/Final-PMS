import React, { useState, useEffect } from 'react';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Edit, Trash2, Upload } from 'lucide-react';
import { Expense, ExpenseCategory, PaymentAccount } from '@/lib/types';
import { expenseStorage } from '@/lib/storage';
import { generateId, formatCurrency, formatDate, validateExpense } from '@/lib/utils-pms';
import ImportDialog from './ImportDialog';
import { importExpenses, SAMPLE_EXPENSE_DATA } from '@/lib/import-utils';
import { getCurrentHotel } from '@/lib/hotel-storage';

const ExpenseManager: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [paymentAccounts, setPaymentAccounts] = useState<PaymentAccount[]>([]);
  const [formData, setFormData] = useState<Partial<Expense>>({
    category: ExpenseCategory.OTHER,
    description: '',
    amount: 0,
    date: new Date().toISOString().split('T')[0],
    vendor: '',
    reference: '',
    notes: '',
    paymentAccountId: ''
  });
  const [errors, setErrors] = useState<string[]>([]);

  useEffect(() => {
    loadExpenses();
    loadPaymentAccounts();
  }, []);

  const loadExpenses = () => {
    setExpenses(expenseStorage.getAll());
  };

  const loadPaymentAccounts = () => {
    const currentHotel = getCurrentHotel();
    if (currentHotel && currentHotel.paymentAccounts) {
      setPaymentAccounts(currentHotel.paymentAccounts);
      if (currentHotel.paymentAccounts.length > 0 && !formData.paymentAccountId) {
        setFormData(prev => ({ ...prev, paymentAccountId: currentHotel.paymentAccounts[0].id }));
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationErrors = validateExpense(formData);
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    const now = new Date().toISOString();
    const expense: Expense = {
      id: editingExpense?.id || generateId(),
      hotelId: '', // Will be set by storage
      category: formData.category!,
      description: formData.description!,
      amount: formData.amount!,
      date: formData.date!,
      vendor: formData.vendor || '',
      reference: formData.reference || '',
      notes: formData.notes || '',
      createdAt: editingExpense?.createdAt || now,
      paymentAccountId: formData.paymentAccountId!
    };

    expenseStorage.save(expense);
    loadExpenses();
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      category: ExpenseCategory.OTHER,
      description: '',
      amount: 0,
      date: new Date().toISOString().split('T')[0],
      vendor: '',
      reference: '',
      notes: '',
      paymentAccountId: paymentAccounts[0]?.id || ''
    });
    setEditingExpense(null);
    setErrors([]);
    setIsDialogOpen(false);
  };

  const handleEdit = (expense: Expense) => {
    setFormData(expense);
    setEditingExpense(expense);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this expense?')) {
      expenseStorage.delete(id);
      loadExpenses();
    }
  };

  const handleImport = async (data: Record<string, string>[]) => {
    const result = await importExpenses(data);
    loadExpenses(); // Refresh the list
    setIsImportDialogOpen(false);
    return result;
  };

  const getPaymentAccountName = (accountId: string) => {
    const account = paymentAccounts.find(acc => acc.id === accountId);
    return account?.name || 'Unknown Account';
  };

  const getCategoryBadge = (category: ExpenseCategory) => {
    const colors: Record<ExpenseCategory, string> = {
      [ExpenseCategory.MAINTENANCE]: 'bg-orange-100 text-orange-800',
      [ExpenseCategory.SUPPLIES]: 'bg-blue-100 text-blue-800',
      [ExpenseCategory.UTILITIES]: 'bg-green-100 text-green-800',
      [ExpenseCategory.MARKETING]: 'bg-purple-100 text-purple-800',
      [ExpenseCategory.STAFF]: 'bg-indigo-100 text-indigo-800',
      [ExpenseCategory.FOOD_BEVERAGE]: 'bg-yellow-100 text-yellow-800',
      [ExpenseCategory.OTHER]: 'bg-gray-100 text-gray-800'
    };
    
    return (
      <Badge className={colors[category]}>
        {category.replace('_', ' ').replace('-', ' ').toUpperCase()}
      </Badge>
    );
  };

  const columns = [
    {
      key: 'description',
      header: 'Description',
      render: (expense: Expense) => (
        <div>
          <div className="font-medium">{expense.description}</div>
          {expense.vendor && (
            <div className="text-sm text-muted-foreground">Vendor: {expense.vendor}</div>
          )}
        </div>
      )
    },
    {
      key: 'category',
      header: 'Category',
      render: (expense: Expense) => getCategoryBadge(expense.category)
    },
    {
      key: 'amount',
      header: 'Amount',
      render: (expense: Expense) => formatCurrency(expense.amount)
    },
    {
      key: 'paymentAccount',
      header: 'Payment Account',
      render: (expense: Expense) => getPaymentAccountName(expense.paymentAccountId)
    },
    {
      key: 'date',
      header: 'Date',
      render: (expense: Expense) => formatDate(expense.date)
    },
    {
      key: 'reference',
      header: 'Reference',
      render: (expense: Expense) => expense.reference || '-'
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (expense: Expense) => (
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleEdit(expense)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleDelete(expense.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
      sortable: false
    }
  ];

  return (
    <div className="space-y-6">
      <DataTable
        data={expenses}
        columns={columns}
        searchKey="description"
        title="Expenses"
        onAdd={() => setIsDialogOpen(true)}
        addButtonText="New Expense"
        extraActions={
          <Button variant="outline" onClick={() => setIsImportDialogOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Import CSV
          </Button>
        }
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingExpense ? 'Edit Expense' : 'New Expense'}
            </DialogTitle>
          </DialogHeader>

          {errors.length > 0 && (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <ul className="text-sm text-destructive space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="description">Description *</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Brief description of the expense"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Category *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category: value as ExpenseCategory }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.values(ExpenseCategory).map(category => (
                      <SelectItem key={category} value={category}>
                        {category.replace('_', ' ').replace('-', ' ').toUpperCase()}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="amount">Amount *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="date">Date *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="paymentAccount">Payment Account *</Label>
                <Select
                  value={formData.paymentAccountId}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, paymentAccountId: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment account" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentAccounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="vendor">Vendor</Label>
              <Input
                id="vendor"
                value={formData.vendor}
                onChange={(e) => setFormData(prev => ({ ...prev, vendor: e.target.value }))}
                placeholder="Supplier or service provider"
              />
            </div>

            <div>
              <Label htmlFor="reference">Reference</Label>
              <Input
                id="reference"
                value={formData.reference}
                onChange={(e) => setFormData(prev => ({ ...prev, reference: e.target.value }))}
                placeholder="Invoice number, receipt ID, etc."
              />
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                rows={3}
                placeholder="Additional notes or details"
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={resetForm}>
                Cancel
              </Button>
              <Button type="submit">
                {editingExpense ? 'Update' : 'Create'} Expense
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ImportDialog
        isOpen={isImportDialogOpen}
        onClose={() => setIsImportDialogOpen(false)}
        onImport={handleImport}
        type="expenses"
        sampleData={SAMPLE_EXPENSE_DATA}
      />
    </div>
  );
};

export default ExpenseManager;