import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Settings, Save, Globe, DollarSign, Clock, Plus, Edit, Trash2, Wallet } from 'lucide-react';
import { Settings as SettingsType, Hotel, PaymentAccount } from '@/lib/types';
import { settingsStorage, hotelStorage, getCurrentHotel } from '@/lib/hotel-storage';
import { CURRENCIES, TIMEZONES } from '@/lib/types';
import { toast } from '@/components/ui/use-toast';

const SettingsManager: React.FC = () => {
  const [settings, setSettings] = useState<SettingsType>({
    currentHotelId: '',
    currency: 'USD',
    timezone: 'America/New_York',
    dateFormat: 'MM/DD/YYYY',
    language: 'en'
  });
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [currentHotel, setCurrentHotel] = useState<Hotel | null>(null);
  const [paymentAccounts, setPaymentAccounts] = useState<PaymentAccount[]>([]);
  const [isAccountDialogOpen, setIsAccountDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<PaymentAccount | null>(null);
  const [accountForm, setAccountForm] = useState({
    name: '',
    type: 'cash' as const
  });

  useEffect(() => {
    loadSettings();
    loadHotels();
    const hotel = getCurrentHotel();
    setCurrentHotel(hotel);
    if (hotel && hotel.paymentAccounts) {
      setPaymentAccounts(hotel.paymentAccounts);
    }
  }, []);

  const loadSettings = () => {
    setSettings(settingsStorage.get());
  };

  const loadHotels = () => {
    setHotels(hotelStorage.getAll());
  };

  const handleSave = () => {
    settingsStorage.save(settings);
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated successfully.",
    });
    
    // If hotel changed, reload the page
    if (currentHotel?.id !== settings.currentHotelId) {
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    }
  };

  const handleHotelChange = (hotelId: string) => {
    setSettings(prev => ({ ...prev, currentHotelId: hotelId }));
  };

  const handleCurrencyChange = (currency: string) => {
    setSettings(prev => ({ ...prev, currency }));
  };

  const handleTimezoneChange = (timezone: string) => {
    setSettings(prev => ({ ...prev, timezone }));
  };

  const resetAccountForm = () => {
    setAccountForm({
      name: '',
      type: 'cash'
    });
    setEditingAccount(null);
  };

  const handleAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentHotel) return;

    if (editingAccount) {
      // Update existing account
      const updatedAccounts = paymentAccounts.map(acc => 
        acc.id === editingAccount.id 
          ? { ...acc, name: accountForm.name, type: accountForm.type }
          : acc
      );
      setPaymentAccounts(updatedAccounts);
      
      // Update hotel with new payment accounts
      const updatedHotel = { ...currentHotel, paymentAccounts: updatedAccounts };
      hotelStorage.save(updatedHotel);
    } else {
      // Add new account
      const newAccount: PaymentAccount = {
        id: Date.now().toString(),
        name: accountForm.name,
        type: accountForm.type,
        balance: 0,
        hotelId: currentHotel.id
      };
      
      const updatedAccounts = [...paymentAccounts, newAccount];
      setPaymentAccounts(updatedAccounts);
      
      // Update hotel with new payment accounts
      const updatedHotel = { ...currentHotel, paymentAccounts: updatedAccounts };
      hotelStorage.save(updatedHotel);
    }

    resetAccountForm();
    setIsAccountDialogOpen(false);
  };

  const handleEditAccount = (account: PaymentAccount) => {
    setEditingAccount(account);
    setAccountForm({
      name: account.name,
      type: account.type
    });
    setIsAccountDialogOpen(true);
  };

  const handleDeleteAccount = (accountId: string) => {
    if (!currentHotel) return;
    if (confirm('Are you sure you want to delete this payment account?')) {
      const updatedAccounts = paymentAccounts.filter(acc => acc.id !== accountId);
      setPaymentAccounts(updatedAccounts);
      
      // Update hotel with new payment accounts
      const updatedHotel = { ...currentHotel, paymentAccounts: updatedAccounts };
      hotelStorage.save(updatedHotel);
    }
  };

  const getAccountTypeIcon = (type: string) => {
    switch (type) {
      case 'cash': return '💵';
      case 'upi': return '📱';
      case 'card': return '💳';
      default: return '🏦';
    }
  };

  const selectedCurrency = CURRENCIES.find(c => c.code === settings.currency);
  const selectedTimezone = TIMEZONES.find(tz => tz.value === settings.timezone);

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="h-6 w-6" />
        <h2 className="text-2xl font-bold">Settings</h2>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="general">General Settings</TabsTrigger>
          <TabsTrigger value="accounts">Payment Accounts</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="space-y-4">
          {/* Current Hotel Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Hotel Selection
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="currentHotel">Active Hotel</Label>
                <Select value={settings.currentHotelId} onValueChange={handleHotelChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a hotel" />
                  </SelectTrigger>
                  <SelectContent>
                    {hotels.map(hotel => (
                      <SelectItem key={hotel.id} value={hotel.id}>
                        {hotel.name} - {hotel.address}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-1">
                  All bookings, payments, and expenses will be associated with the selected hotel.
                </p>
              </div>

              {currentHotel && (
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Current Hotel Details:</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Name:</span> {currentHotel.name}
                    </div>
                    <div>
                      <span className="font-medium">Rooms:</span> {currentHotel.totalRooms}
                    </div>
                    <div>
                      <span className="font-medium">Phone:</span> {currentHotel.phone}
                    </div>
                    <div>
                      <span className="font-medium">Email:</span> {currentHotel.email}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Separator />

          {/* Currency Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Currency Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="currency">Default Currency</Label>
                <Select value={settings.currency} onValueChange={handleCurrencyChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CURRENCIES.map(currency => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.symbol} {currency.name} ({currency.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-1">
                  This currency will be used for all financial calculations and displays.
                </p>
              </div>

              {selectedCurrency && (
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Currency Preview:</h4>
                  <div className="text-sm space-y-1">
                    <div>Symbol: <span className="font-mono">{selectedCurrency.symbol}</span></div>
                    <div>Sample Amount: <span className="font-mono">{selectedCurrency.symbol}1,234.56</span></div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Separator />

          {/* Timezone Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Timezone Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="timezone">Default Timezone</Label>
                <Select value={settings.timezone} onValueChange={handleTimezoneChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TIMEZONES.map(tz => (
                      <SelectItem key={tz.value} value={tz.value}>
                        {tz.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-1">
                  This timezone will be used for all date and time displays.
                </p>
              </div>

              {selectedTimezone && (
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Timezone Preview:</h4>
                  <div className="text-sm space-y-1">
                    <div>Selected: <span className="font-mono">{selectedTimezone.label}</span></div>
                    <div>Current Time: <span className="font-mono">
                      {new Date().toLocaleString('en-US', { 
                        timeZone: settings.timezone,
                        dateStyle: 'medium',
                        timeStyle: 'short'
                      })}
                    </span></div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} className="flex items-center gap-2">
              <Save className="h-4 w-4" />
              Save Settings
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="accounts" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Payment Accounts</h3>
            <Dialog open={isAccountDialogOpen} onOpenChange={setIsAccountDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => { resetAccountForm(); setIsAccountDialogOpen(true); }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Account
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {editingAccount ? 'Edit Payment Account' : 'Add Payment Account'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAccountSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="accountName">Account Name</Label>
                    <Input
                      id="accountName"
                      value={accountForm.name}
                      onChange={(e) => setAccountForm({ ...accountForm, name: e.target.value })}
                      placeholder="e.g., Cash Received, Manish UPI/Card"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="accountType">Account Type</Label>
                    <Select value={accountForm.type} onValueChange={(value) => setAccountForm({ ...accountForm, type: value as 'cash' | 'upi' | 'card' | 'other' })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="upi">UPI</SelectItem>
                        <SelectItem value="card">Card</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setIsAccountDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingAccount ? 'Update Account' : 'Add Account'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {paymentAccounts.map((account) => (
              <Card key={account.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{getAccountTypeIcon(account.type)}</div>
                      <div>
                        <h4 className="font-semibold text-lg">{account.name}</h4>
                        <p className="text-sm text-gray-500 capitalize">{account.type}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-2 mb-2">
                        <Wallet className="w-4 h-4 text-gray-500" />
                        <span className={`text-xl font-bold ${account.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          ${account.balance.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleEditAccount(account)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteAccount(account.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {paymentAccounts.length === 0 && (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-gray-500">No payment accounts configured. Add your first payment account to get started.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SettingsManager;