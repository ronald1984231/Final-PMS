import React, { useState, useEffect } from 'react';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Edit, Trash2, Upload } from 'lucide-react';
import { Payment, PaymentMethod, PaymentStatus, Booking } from '@/lib/types';
import { paymentStorage, bookingStorage } from '@/lib/storage';
import { generateId, formatCurrency, formatDate, validatePayment } from '@/lib/utils-pms';
import ImportDialog from './ImportDialog';
import { importPayments, SAMPLE_PAYMENT_DATA } from '@/lib/import-utils';

const PaymentManager: React.FC = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);
  const [formData, setFormData] = useState<Partial<Payment>>({
    bookingId: '',
    amount: 0,
    paymentMethod: PaymentMethod.CASH,
    status: PaymentStatus.PENDING,
    paymentDate: new Date().toISOString().split('T')[0],
    reference: '',
    notes: ''
  });
  const [errors, setErrors] = useState<string[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setPayments(paymentStorage.getAll());
    setBookings(bookingStorage.getAll());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationErrors = validatePayment(formData);
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }

    const now = new Date().toISOString();
    const payment: Payment = {
      id: editingPayment?.id || generateId(),
      hotelId: '', // Will be set by storage
      bookingId: formData.bookingId!,
      amount: formData.amount!,
      paymentMethod: formData.paymentMethod!,
      status: formData.status!,
      paymentDate: formData.paymentDate!,
      reference: formData.reference || '',
      notes: formData.notes || '',
      createdAt: editingPayment?.createdAt || now
    };

    paymentStorage.save(payment);
    loadData();
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      bookingId: '',
      amount: 0,
      paymentMethod: PaymentMethod.CASH,
      status: PaymentStatus.PENDING,
      paymentDate: new Date().toISOString().split('T')[0],
      reference: '',
      notes: ''
    });
    setEditingPayment(null);
    setErrors([]);
    setIsDialogOpen(false);
  };

  const handleEdit = (payment: Payment) => {
    setFormData(payment);
    setEditingPayment(payment);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this payment?')) {
      paymentStorage.delete(id);
      loadData();
    }
  };

  const handleImport = async (data: Record<string, string>[]) => {
    const result = await importPayments(data);
    loadData(); // Refresh the list
    setIsImportDialogOpen(false);
    return result;
  };

  const getStatusBadge = (status: PaymentStatus) => {
    const variants: Record<PaymentStatus, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      [PaymentStatus.PENDING]: 'outline',
      [PaymentStatus.COMPLETED]: 'default',
      [PaymentStatus.FAILED]: 'destructive',
      [PaymentStatus.REFUNDED]: 'secondary'
    };
    
    return <Badge variant={variants[status]}>{status}</Badge>;
  };

  const getBookingInfo = (bookingId: string) => {
    const booking = bookings.find(b => b.id === bookingId);
    return booking ? `${booking.guestName} - Room ${booking.roomNumber}` : 'Unknown Booking';
  };

  const columns = [
    {
      key: 'bookingId',
      header: 'Booking',
      render: (payment: Payment) => (
        <div>
          <div className="font-medium">{getBookingInfo(payment.bookingId)}</div>
          <div className="text-sm text-muted-foreground">ID: {payment.bookingId}</div>
        </div>
      )
    },
    {
      key: 'amount',
      header: 'Amount',
      render: (payment: Payment) => formatCurrency(payment.amount)
    },
    {
      key: 'paymentMethod',
      header: 'Method',
      render: (payment: Payment) => (
        <Badge variant="outline">
          {payment.paymentMethod.replace('-', ' ').toUpperCase()}
        </Badge>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (payment: Payment) => getStatusBadge(payment.status)
    },
    {
      key: 'paymentDate',
      header: 'Date',
      render: (payment: Payment) => formatDate(payment.paymentDate)
    },
    {
      key: 'reference',
      header: 'Reference',
      render: (payment: Payment) => payment.reference || '-'
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (payment: Payment) => (
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleEdit(payment)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleDelete(payment.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
      sortable: false
    }
  ];

  return (
    <div className="space-y-6">
      <DataTable
        data={payments}
        columns={columns}
        title="Payments"
        onAdd={() => setIsDialogOpen(true)}
        addButtonText="New Payment"
        extraActions={
          <Button variant="outline" onClick={() => setIsImportDialogOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Import CSV
          </Button>
        }
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingPayment ? 'Edit Payment' : 'New Payment'}
            </DialogTitle>
          </DialogHeader>

          {errors.length > 0 && (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <ul className="text-sm text-destructive space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="bookingId">Booking *</Label>
              <Select
                value={formData.bookingId}
                onValueChange={(value) => setFormData(prev => ({ ...prev, bookingId: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a booking" />
                </SelectTrigger>
                <SelectContent>
                  {bookings.map(booking => (
                    <SelectItem key={booking.id} value={booking.id}>
                      {booking.guestName} - Room {booking.roomNumber} ({formatCurrency(booking.totalAmount)})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="amount">Amount *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                />
              </div>
              <div>
                <Label htmlFor="paymentDate">Payment Date *</Label>
                <Input
                  id="paymentDate"
                  type="date"
                  value={formData.paymentDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, paymentDate: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="paymentMethod">Payment Method *</Label>
                <Select
                  value={formData.paymentMethod}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, paymentMethod: value as PaymentMethod }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.values(PaymentMethod).map(method => (
                      <SelectItem key={method} value={method}>
                        {method.replace('-', ' ').toUpperCase()}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="status">Status *</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, status: value as PaymentStatus }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.values(PaymentStatus).map(status => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="reference">Reference</Label>
              <Input
                id="reference"
                value={formData.reference}
                onChange={(e) => setFormData(prev => ({ ...prev, reference: e.target.value }))}
                placeholder="Transaction ID, Check number, etc."
              />
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={resetForm}>
                Cancel
              </Button>
              <Button type="submit">
                {editingPayment ? 'Update' : 'Create'} Payment
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ImportDialog
        isOpen={isImportDialogOpen}
        onClose={() => setIsImportDialogOpen(false)}
        onImport={handleImport}
        type="payments"
        sampleData={SAMPLE_PAYMENT_DATA}
      />
    </div>
  );
};

export default PaymentManager;