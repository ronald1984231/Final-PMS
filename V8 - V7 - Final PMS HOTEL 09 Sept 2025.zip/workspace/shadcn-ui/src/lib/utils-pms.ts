import { Booking, Payment, Expense, DashboardStats, BookingStatus, PaymentStatus, Hotel } from './types';
import { bookingStorage, paymentStorage, expenseStorage } from './storage';
import { settingsStorage, getCurrentHotel } from './hotel-storage';

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const formatCurrency = (amount: number): string => {
  const settings = settingsStorage.get();
  const hotel = getCurrentHotel();
  const currency = hotel?.currency || settings.currency || 'USD';
  
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency
  }).format(amount);
};

export const formatDate = (date: string): string => {
  const settings = settingsStorage.get();
  const hotel = getCurrentHotel();
  const timezone = hotel?.timezone || settings.timezone || 'America/New_York';
  
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    timeZone: timezone
  });
};

export const formatDateTime = (date: string): string => {
  const settings = settingsStorage.get();
  const hotel = getCurrentHotel();
  const timezone = hotel?.timezone || settings.timezone || 'America/New_York';
  
  return new Date(date).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: timezone
  });
};

export const calculateBookingBalance = (booking: Booking): number => {
  const payments = paymentStorage.getByBookingId(booking.id);
  const totalPaid = payments
    .filter(p => p.status === PaymentStatus.COMPLETED)
    .reduce((sum, p) => sum + p.amount, 0);
  
  return booking.totalAmount - totalPaid;
};

export const getBookingPaymentStatus = (booking: Booking): 'paid' | 'partial' | 'unpaid' => {
  const balance = calculateBookingBalance(booking);
  
  if (balance <= 0) return 'paid';
  if (balance < booking.totalAmount) return 'partial';
  return 'unpaid';
};

export const calculateDashboardStats = (): DashboardStats => {
  const bookings = bookingStorage.getAll();
  const payments = paymentStorage.getAll();
  const expenses = expenseStorage.getAll();
  
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  // Filter current month data
  const currentMonthBookings = bookings.filter(b => {
    const bookingDate = new Date(b.createdAt);
    return bookingDate.getMonth() === currentMonth && bookingDate.getFullYear() === currentYear;
  });
  
  const currentMonthPayments = payments.filter(p => {
    const paymentDate = new Date(p.paymentDate);
    return paymentDate.getMonth() === currentMonth && paymentDate.getFullYear() === currentYear;
  });
  
  const currentMonthExpenses = expenses.filter(e => {
    const expenseDate = new Date(e.date);
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear;
  });
  
  // Calculate totals
  const totalRevenue = currentMonthPayments
    .filter(p => p.status === PaymentStatus.COMPLETED)
    .reduce((sum, p) => sum + p.amount, 0);
  
  const pendingPayments = payments
    .filter(p => p.status === PaymentStatus.PENDING)
    .reduce((sum, p) => sum + p.amount, 0);
  
  const monthlyExpenses = currentMonthExpenses
    .reduce((sum, e) => sum + e.amount, 0);
  
  // Calculate occupancy rate (simplified - based on confirmed/checked-in bookings)
  const occupiedRooms = bookings.filter(b => 
    b.status === BookingStatus.CONFIRMED || b.status === BookingStatus.CHECKED_IN
  ).length;
  
  const hotel = getCurrentHotel();
  const totalRooms = hotel?.totalRooms || 50;
  const occupancyRate = (occupiedRooms / totalRooms) * 100;
  
  return {
    totalBookings: currentMonthBookings.length,
    totalRevenue,
    pendingPayments,
    monthlyExpenses,
    occupancyRate,
    recentBookings: bookings
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5),
    recentPayments: payments
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5),
    recentExpenses: expenses
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5)
  };
};

export const validateBooking = (booking: Partial<Booking>): string[] => {
  const errors: string[] = [];
  
  if (!booking.guestName?.trim()) {
    errors.push('Guest name is required');
  }
  
  if (!booking.email?.trim() || !/\S+@\S+\.\S+/.test(booking.email)) {
    errors.push('Valid email is required');
  }
  
  if (!booking.phone?.trim()) {
    errors.push('Phone number is required');
  }
  
  if (!booking.roomNumber?.trim()) {
    errors.push('Room number is required');
  }
  
  if (!booking.checkInDate) {
    errors.push('Check-in date is required');
  }
  
  if (!booking.checkOutDate) {
    errors.push('Check-out date is required');
  }
  
  if (booking.checkInDate && booking.checkOutDate) {
    const checkIn = new Date(booking.checkInDate);
    const checkOut = new Date(booking.checkOutDate);
    
    if (checkOut <= checkIn) {
      errors.push('Check-out date must be after check-in date');
    }
  }
  
  if (!booking.totalAmount || booking.totalAmount <= 0) {
    errors.push('Total amount must be greater than 0');
  }
  
  return errors;
};

export const validatePayment = (payment: Partial<Payment>): string[] => {
  const errors: string[] = [];
  
  if (!payment.bookingId) {
    errors.push('Booking is required');
  }
  
  if (!payment.amount || payment.amount <= 0) {
    errors.push('Amount must be greater than 0');
  }
  
  if (!payment.paymentMethod) {
    errors.push('Payment method is required');
  }
  
  if (!payment.paymentDate) {
    errors.push('Payment date is required');
  }
  
  return errors;
};

export const validateExpense = (expense: Partial<Expense>): string[] => {
  const errors: string[] = [];
  
  if (!expense.description?.trim()) {
    errors.push('Description is required');
  }
  
  if (!expense.amount || expense.amount <= 0) {
    errors.push('Amount must be greater than 0');
  }
  
  if (!expense.category) {
    errors.push('Category is required');
  }
  
  if (!expense.date) {
    errors.push('Date is required');
  }
  
  return errors;
};

export const validateHotel = (hotel: Partial<Hotel>): string[] => {
  const errors: string[] = [];
  
  if (!hotel.name?.trim()) {
    errors.push('Hotel name is required');
  }
  
  if (!hotel.address?.trim()) {
    errors.push('Address is required');
  }
  
  if (!hotel.phone?.trim()) {
    errors.push('Phone number is required');
  }
  
  if (!hotel.email?.trim() || !/\S+@\S+\.\S+/.test(hotel.email)) {
    errors.push('Valid email is required');
  }
  
  if (!hotel.totalRooms || hotel.totalRooms <= 0) {
    errors.push('Total rooms must be greater than 0');
  }
  
  if (!hotel.currency?.trim()) {
    errors.push('Currency is required');
  }
  
  if (!hotel.timezone?.trim()) {
    errors.push('Timezone is required');
  }
  
  return errors;
};