import { Booking, Payment, Expense, BookingStatus, PaymentStatus, PaymentMethod, ExpenseCategory } from './types';
import { getCurrentHotel } from './hotel-storage';

const STORAGE_KEYS = {
  BOOKINGS: 'hotel-pms-bookings',
  PAYMENTS: 'hotel-pms-payments',
  EXPENSES: 'hotel-pms-expenses'
};

// Generic storage functions
function getFromStorage<T>(key: string): T[] {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading from storage (${key}):`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to storage (${key}):`, error);
  }
}

// Get current hotel ID
function getCurrentHotelId(): string {
  const hotel = getCurrentHotel();
  return hotel?.id || '';
}

// Booking operations (hotel-specific)
export const bookingStorage = {
  getAll: (): Booking[] => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return [];
    return getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS)
      .filter(booking => booking.hotelId === hotelId);
  },
  
  save: (booking: Booking): void => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return;
    
    booking.hotelId = hotelId;
    const allBookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    const existingIndex = allBookings.findIndex(b => b.id === booking.id);
    
    if (existingIndex >= 0) {
      allBookings[existingIndex] = { ...booking, updatedAt: new Date().toISOString() };
    } else {
      allBookings.push(booking);
    }
    
    saveToStorage(STORAGE_KEYS.BOOKINGS, allBookings);
  },
  
  delete: (id: string): void => {
    const allBookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    const filteredBookings = allBookings.filter(b => b.id !== id);
    saveToStorage(STORAGE_KEYS.BOOKINGS, filteredBookings);
  },
  
  getById: (id: string): Booking | undefined => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return undefined;
    return getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS)
      .find(b => b.id === id && b.hotelId === hotelId);
  }
};

// Payment operations (hotel-specific)
export const paymentStorage = {
  getAll: (): Payment[] => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return [];
    return getFromStorage<Payment>(STORAGE_KEYS.PAYMENTS)
      .filter(payment => payment.hotelId === hotelId);
  },
  
  save: (payment: Payment): void => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return;
    
    payment.hotelId = hotelId;
    const allPayments = getFromStorage<Payment>(STORAGE_KEYS.PAYMENTS);
    const existingIndex = allPayments.findIndex(p => p.id === payment.id);
    
    if (existingIndex >= 0) {
      allPayments[existingIndex] = payment;
    } else {
      allPayments.push(payment);
    }
    
    saveToStorage(STORAGE_KEYS.PAYMENTS, allPayments);
  },
  
  delete: (id: string): void => {
    const allPayments = getFromStorage<Payment>(STORAGE_KEYS.PAYMENTS);
    const filteredPayments = allPayments.filter(p => p.id !== id);
    saveToStorage(STORAGE_KEYS.PAYMENTS, filteredPayments);
  },
  
  getByBookingId: (bookingId: string): Payment[] => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return [];
    return getFromStorage<Payment>(STORAGE_KEYS.PAYMENTS)
      .filter(p => p.bookingId === bookingId && p.hotelId === hotelId);
  }
};

// Expense operations (hotel-specific)
export const expenseStorage = {
  getAll: (): Expense[] => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return [];
    return getFromStorage<Expense>(STORAGE_KEYS.EXPENSES)
      .filter(expense => expense.hotelId === hotelId);
  },
  
  save: (expense: Expense): void => {
    const hotelId = getCurrentHotelId();
    if (!hotelId) return;
    
    expense.hotelId = hotelId;
    const allExpenses = getFromStorage<Expense>(STORAGE_KEYS.EXPENSES);
    const existingIndex = allExpenses.findIndex(e => e.id === expense.id);
    
    if (existingIndex >= 0) {
      allExpenses[existingIndex] = expense;
    } else {
      allExpenses.push(expense);
    }
    
    saveToStorage(STORAGE_KEYS.EXPENSES, allExpenses);
  },
  
  delete: (id: string): void => {
    const allExpenses = getFromStorage<Expense>(STORAGE_KEYS.EXPENSES);
    const filteredExpenses = allExpenses.filter(e => e.id !== id);
    saveToStorage(STORAGE_KEYS.EXPENSES, filteredExpenses);
  }
};

// Initialize with sample data if empty (hotel-specific)
export const initializeSampleData = (): void => {
  const hotelId = getCurrentHotelId();
  if (!hotelId) return;
  
  if (bookingStorage.getAll().length === 0) {
    const sampleBookings: Booking[] = [
      {
        id: '1',
        hotelId,
        guestName: 'John Smith',
        email: 'john.smith@email.com',
        phone: '+1-555-0123',
        roomNumber: '101',
        roomType: 'Standard',
        checkInDate: '2025-01-15',
        checkOutDate: '2025-01-18',
        totalAmount: 450,
        status: BookingStatus.CONFIRMED,
        createdAt: '2025-01-10T10:00:00Z',
        updatedAt: '2025-01-10T10:00:00Z',
        notes: 'Late check-in requested'
      }
    ];
    
    const samplePayments: Payment[] = [
      {
        id: '1',
        hotelId,
        bookingId: '1',
        amount: 225,
        paymentMethod: PaymentMethod.CREDIT_CARD,
        status: PaymentStatus.COMPLETED,
        paymentDate: '2025-01-10',
        reference: 'CC-001',
        createdAt: '2025-01-10T10:30:00Z'
      }
    ];
    
    const sampleExpenses: Expense[] = [
      {
        id: '1',
        hotelId,
        category: ExpenseCategory.MAINTENANCE,
        description: 'Room 205 AC repair',
        amount: 150,
        date: '2025-01-08',
        vendor: 'Cool Air Services',
        reference: 'INV-2025-001',
        createdAt: '2025-01-08T14:00:00Z'
      }
    ];
    
    // Save to all data (not hotel-specific storage)
    const allBookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    const allPayments = getFromStorage<Payment>(STORAGE_KEYS.PAYMENTS);
    const allExpenses = getFromStorage<Expense>(STORAGE_KEYS.EXPENSES);
    
    saveToStorage(STORAGE_KEYS.BOOKINGS, [...allBookings, ...sampleBookings]);
    saveToStorage(STORAGE_KEYS.PAYMENTS, [...allPayments, ...samplePayments]);
    saveToStorage(STORAGE_KEYS.EXPENSES, [...allExpenses, ...sampleExpenses]);
  }
};