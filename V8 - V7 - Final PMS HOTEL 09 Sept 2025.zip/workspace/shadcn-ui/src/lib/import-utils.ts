import { Booking, Payment, Expense, BookingStatus, PaymentStatus, PaymentMethod, ExpenseCategory } from './types';
import { bookingStorage, paymentStorage, expenseStorage } from './storage';
import { validateBooking, validatePayment, validateExpense, generateId } from './utils-pms';
import { getCurrentHotel } from './hotel-storage';

// Sample data for CSV templates
export const SAMPLE_BOOKING_DATA = {
  guestName: 'John Smith',
  email: 'john.smith@email.com',
  phone: '+1-555-0123',
  roomNumber: '101',
  roomType: 'Standard',
  checkInDate: '2025-01-15',
  checkOutDate: '2025-01-18',
  totalAmount: '450.00',
  status: 'confirmed',
  notes: 'Late check-in requested',
  createdAt: '2025-01-10T10:00:00Z'
};

export const SAMPLE_PAYMENT_DATA = {
  bookingId: 'booking-id-here',
  amount: '225.00',
  paymentMethod: 'credit_card',
  status: 'completed',
  paymentDate: '2025-01-10',
  reference: 'CC-001',
  notes: 'Partial payment',
  createdAt: '2025-01-10T10:30:00Z'
};

export const SAMPLE_EXPENSE_DATA = {
  category: 'maintenance',
  description: 'Room 205 AC repair',
  amount: '150.00',
  date: '2025-01-08',
  vendor: 'Cool Air Services',
  reference: 'INV-2025-001',
  notes: 'Emergency repair',
  createdAt: '2025-01-08T14:00:00Z'
};

// Import functions
export const importBookings = async (data: Record<string, string>[]): Promise<{ success: number; errors: string[] }> => {
  const hotel = getCurrentHotel();
  if (!hotel) {
    return { success: 0, errors: ['No hotel selected'] };
  }

  let success = 0;
  const errors: string[] = [];

  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    
    try {
      // Map CSV columns to booking object
      const booking: Partial<Booking> = {
        guestName: row.guestName || row.guest_name || row['Guest Name'],
        email: row.email || row.Email,
        phone: row.phone || row.Phone,
        roomNumber: row.roomNumber || row.room_number || row['Room Number'],
        roomType: row.roomType || row.room_type || row['Room Type'] || 'Standard',
        checkInDate: row.checkInDate || row.check_in_date || row['Check In Date'],
        checkOutDate: row.checkOutDate || row.check_out_date || row['Check Out Date'],
        totalAmount: parseFloat(row.totalAmount || row.total_amount || row['Total Amount'] || '0'),
        status: (row.status || row.Status || 'pending').toLowerCase() as BookingStatus,
        notes: row.notes || row.Notes || '',
        createdAt: row.createdAt || row.created_at || row['Created At'] || new Date().toISOString()
      };

      // Validate booking
      const validationErrors = validateBooking(booking);
      if (validationErrors.length > 0) {
        errors.push(`Row ${i + 2}: ${validationErrors.join(', ')}`);
        continue;
      }

      // Create booking with ID and hotel ID
      const newBooking: Booking = {
        id: generateId(),
        hotelId: hotel.id,
        guestName: booking.guestName!,
        email: booking.email!,
        phone: booking.phone!,
        roomNumber: booking.roomNumber!,
        roomType: booking.roomType!,
        checkInDate: booking.checkInDate!,
        checkOutDate: booking.checkOutDate!,
        totalAmount: booking.totalAmount!,
        status: booking.status!,
        notes: booking.notes || '',
        createdAt: booking.createdAt!,
        updatedAt: new Date().toISOString()
      };

      // Save booking
      bookingStorage.save(newBooking);
      success++;

    } catch (error) {
      errors.push(`Row ${i + 2}: Invalid data format`);
    }
  }

  return { success, errors };
};

export const importPayments = async (data: Record<string, string>[]): Promise<{ success: number; errors: string[] }> => {
  const hotel = getCurrentHotel();
  if (!hotel) {
    return { success: 0, errors: ['No hotel selected'] };
  }

  let success = 0;
  const errors: string[] = [];

  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    
    try {
      // Map CSV columns to payment object
      const payment: Partial<Payment> = {
        bookingId: row.bookingId || row.booking_id || row['Booking ID'],
        amount: parseFloat(row.amount || row.Amount || '0'),
        paymentMethod: (row.paymentMethod || row.payment_method || row['Payment Method'] || 'cash').toLowerCase().replace(' ', '_') as PaymentMethod,
        status: (row.status || row.Status || 'pending').toLowerCase() as PaymentStatus,
        paymentDate: row.paymentDate || row.payment_date || row['Payment Date'],
        reference: row.reference || row.Reference || '',
        notes: row.notes || row.Notes || '',
        createdAt: row.createdAt || row.created_at || row['Created At'] || new Date().toISOString()
      };

      // Validate payment
      const validationErrors = validatePayment(payment);
      if (validationErrors.length > 0) {
        errors.push(`Row ${i + 2}: ${validationErrors.join(', ')}`);
        continue;
      }

      // Check if booking exists (optional validation)
      if (payment.bookingId) {
        const booking = bookingStorage.getById(payment.bookingId);
        if (!booking) {
          errors.push(`Row ${i + 2}: Booking ID ${payment.bookingId} not found`);
          continue;
        }
      }

      // Create payment with ID and hotel ID
      const newPayment: Payment = {
        id: generateId(),
        hotelId: hotel.id,
        bookingId: payment.bookingId!,
        amount: payment.amount!,
        paymentMethod: payment.paymentMethod!,
        status: payment.status!,
        paymentDate: payment.paymentDate!,
        reference: payment.reference,
        notes: payment.notes,
        createdAt: payment.createdAt!
      };

      // Save payment
      paymentStorage.save(newPayment);
      success++;

    } catch (error) {
      errors.push(`Row ${i + 2}: Invalid data format`);
    }
  }

  return { success, errors };
};

export const importExpenses = async (data: Record<string, string>[]): Promise<{ success: number; errors: string[] }> => {
  const hotel = getCurrentHotel();
  if (!hotel) {
    return { success: 0, errors: ['No hotel selected'] };
  }

  let success = 0;
  const errors: string[] = [];

  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    
    try {
      // Map CSV columns to expense object
      const expense: Partial<Expense> = {
        category: (row.category || row.Category || 'other').toLowerCase().replace(' ', '_') as ExpenseCategory,
        description: row.description || row.Description,
        amount: parseFloat(row.amount || row.Amount || '0'),
        date: row.date || row.Date,
        vendor: row.vendor || row.Vendor || '',
        reference: row.reference || row.Reference || '',
        notes: row.notes || row.Notes || '',
        createdAt: row.createdAt || row.created_at || row['Created At'] || new Date().toISOString()
      };

      // Validate expense
      const validationErrors = validateExpense(expense);
      if (validationErrors.length > 0) {
        errors.push(`Row ${i + 2}: ${validationErrors.join(', ')}`);
        continue;
      }

      // Create expense with ID and hotel ID
      const newExpense: Expense = {
        id: generateId(),
        hotelId: hotel.id,
        category: expense.category!,
        description: expense.description!,
        amount: expense.amount!,
        date: expense.date!,
        vendor: expense.vendor,
        reference: expense.reference,
        notes: expense.notes,
        createdAt: expense.createdAt!
      };

      // Save expense
      expenseStorage.save(newExpense);
      success++;

    } catch (error) {
      errors.push(`Row ${i + 2}: Invalid data format`);
    }
  }

  return { success, errors };
};