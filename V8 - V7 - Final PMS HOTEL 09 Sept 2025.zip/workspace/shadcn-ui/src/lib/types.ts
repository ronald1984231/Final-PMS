// Enums
export enum BookingStatus {
  PENDING = 'pending',
  CONFIRMED = 'confirmed',
  CHECKED_IN = 'checked_in',
  CHECKED_OUT = 'checked_out',
  CANCELLED = 'cancelled'
}

export enum PaymentStatus {
  PENDING = 'pending',
  COMPLETED = 'completed',
  FAILED = 'failed',
  REFUNDED = 'refunded'
}

export enum PaymentMethod {
  CASH = 'cash',
  CREDIT_CARD = 'credit_card',
  DEBIT_CARD = 'debit_card',
  BANK_TRANSFER = 'bank_transfer',
  DIGITAL_WALLET = 'digital_wallet'
}

export enum ExpenseCategory {
  MAINTENANCE = 'maintenance',
  UTILITIES = 'utilities',
  SUPPLIES = 'supplies',
  MARKETING = 'marketing',
  STAFF = 'staff',
  FOOD_BEVERAGE = 'food_beverage',
  OTHER = 'other'
}

// Payment Account Management
export interface PaymentAccount {
  id: string;
  name: string;
  type: 'cash' | 'upi' | 'card' | 'other';
  balance: number;
  hotelId: string;
}

export interface BookingPayment {
  id: string;
  amount: number;
  paymentDate: string;
  paymentAccountId: string;
  notes?: string;
}

// Hotel Management
export interface Hotel {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  totalRooms: number;
  currency: string;
  timezone: string;
  createdAt: string;
  updatedAt: string;
  paymentAccounts: PaymentAccount[];
}

export interface Settings {
  currentHotelId: string;
  currency: string;
  timezone: string;
  dateFormat: string;
  language: string;
}

// Core entities (now hotel-specific)
export interface Booking {
  id: string;
  hotelId: string;
  guestName: string;
  email: string;
  phone: string;
  roomNumber: string;
  roomType: string;
  checkInDate: string;
  checkOutDate: string;
  totalAmount: number;
  status: BookingStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  payments: BookingPayment[];
}

export interface Payment {
  id: string;
  hotelId: string;
  bookingId: string;
  amount: number;
  paymentMethod: PaymentMethod;
  status: PaymentStatus;
  paymentDate: string;
  reference?: string;
  notes?: string;
  createdAt: string;
  paymentAccountId: string;
}

export interface Expense {
  id: string;
  hotelId: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  date: string;
  vendor?: string;
  reference?: string;
  notes?: string;
  createdAt: string;
  paymentAccountId: string;
}

export interface DashboardStats {
  totalBookings: number;
  totalRevenue: number;
  pendingPayments: number;
  monthlyExpenses: number;
  occupancyRate: number;
  recentBookings: Booking[];
  recentPayments: Payment[];
  recentExpenses: Expense[];
}

// Currency and Timezone options
export const CURRENCIES = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'CHF', symbol: 'Fr', name: 'Swiss Franc' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' }
];

export const TIMEZONES = [
  { value: 'America/New_York', label: 'Eastern Time (ET)' },
  { value: 'America/Chicago', label: 'Central Time (CT)' },
  { value: 'America/Denver', label: 'Mountain Time (MT)' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
  { value: 'Europe/London', label: 'Greenwich Mean Time (GMT)' },
  { value: 'Europe/Paris', label: 'Central European Time (CET)' },
  { value: 'Europe/Berlin', label: 'Central European Time (CET)' },
  { value: 'Asia/Tokyo', label: 'Japan Standard Time (JST)' },
  { value: 'Asia/Shanghai', label: 'China Standard Time (CST)' },
  { value: 'Asia/Kolkata', label: 'India Standard Time (IST)' },
  { value: 'Australia/Sydney', label: 'Australian Eastern Time (AET)' }
];