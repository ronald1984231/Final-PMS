import { supabase } from './supabase';
import { Hotel, PaymentAccount, Booking, Payment, Expense, BookingPayment } from './types';

// Hotel Management
export const createHotel = async (hotel: Omit<Hotel, 'id' | 'paymentAccounts' | 'createdAt' | 'updatedAt'>): Promise<Hotel | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('No authenticated user');

    const { data, error } = await supabase
      .from('app_b228d5f965_hotels')
      .insert({
        user_id: user.id,
        name: hotel.name,
        address: hotel.address,
        phone: hotel.phone,
        email: hotel.email,
        currency: hotel.currency || 'USD',
        timezone: hotel.timezone || 'UTC',
        total_rooms: hotel.totalRooms || 50
      })
      .select()
      .single();

    if (error) throw error;

    // Create default payment accounts for the hotel
    const defaultAccounts = [
      { name: 'Cash Received', type: 'cash' },
      { name: 'Oyo Received', type: 'other' },
      { name: 'Manish UPI/Card', type: 'upi' },
      { name: 'Samay UPI/Card', type: 'upi' }
    ];

    const { error: accountsError } = await supabase
      .from('app_b228d5f965_payment_accounts')
      .insert(
        defaultAccounts.map(account => ({
          user_id: user.id,
          hotel_id: data.id,
          name: account.name,
          type: account.type,
          balance: 0
        }))
      );

    if (accountsError) console.error('Error creating default payment accounts:', accountsError);

    return {
      id: data.id,
      name: data.name,
      address: data.address,
      phone: data.phone,
      email: data.email,
      currency: data.currency,
      timezone: data.timezone,
      totalRooms: data.total_rooms,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
      paymentAccounts: []
    };
  } catch (error) {
    console.error('Error creating hotel:', error);
    return null;
  }
};

export const getHotels = async (): Promise<Hotel[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('app_b228d5f965_hotels')
      .select(`
        *,
        app_b228d5f965_payment_accounts (
          id,
          name,
          type,
          balance,
          created_at,
          updated_at
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data.map(hotel => ({
      id: hotel.id,
      name: hotel.name,
      address: hotel.address,
      phone: hotel.phone,
      email: hotel.email,
      currency: hotel.currency,
      timezone: hotel.timezone,
      totalRooms: hotel.total_rooms,
      createdAt: hotel.created_at,
      updatedAt: hotel.updated_at,
      paymentAccounts: hotel.app_b228d5f965_payment_accounts.map((account: any) => ({
        id: account.id,
        name: account.name,
        type: account.type,
        balance: parseFloat(account.balance),
        hotelId: hotel.id
      }))
    }));
  } catch (error) {
    console.error('Error fetching hotels:', error);
    return [];
  }
};

export const updateHotel = async (hotelId: string, updates: Partial<Hotel>): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from('app_b228d5f965_hotels')
      .update({
        name: updates.name,
        address: updates.address,
        phone: updates.phone,
        email: updates.email,
        currency: updates.currency,
        timezone: updates.timezone,
        total_rooms: updates.totalRooms,
        updated_at: new Date().toISOString()
      })
      .eq('id', hotelId)
      .eq('user_id', user.id);

    return !error;
  } catch (error) {
    console.error('Error updating hotel:', error);
    return false;
  }
};

export const deleteHotel = async (hotelId: string): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from('app_b228d5f965_hotels')
      .delete()
      .eq('id', hotelId)
      .eq('user_id', user.id);

    return !error;
  } catch (error) {
    console.error('Error deleting hotel:', error);
    return false;
  }
};

// Payment Account Management
export const createPaymentAccount = async (hotelId: string, account: Omit<PaymentAccount, 'id' | 'hotelId' | 'balance'>): Promise<PaymentAccount | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('app_b228d5f965_payment_accounts')
      .insert({
        user_id: user.id,
        hotel_id: hotelId,
        name: account.name,
        type: account.type,
        balance: 0
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      name: data.name,
      type: data.type,
      balance: parseFloat(data.balance),
      hotelId: data.hotel_id
    };
  } catch (error) {
    console.error('Error creating payment account:', error);
    return null;
  }
};

export const getPaymentAccounts = async (hotelId: string): Promise<PaymentAccount[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('app_b228d5f965_payment_accounts')
      .select('*')
      .eq('user_id', user.id)
      .eq('hotel_id', hotelId)
      .order('created_at', { ascending: true });

    if (error) throw error;

    return data.map(account => ({
      id: account.id,
      name: account.name,
      type: account.type,
      balance: parseFloat(account.balance),
      hotelId: account.hotel_id
    }));
  } catch (error) {
    console.error('Error fetching payment accounts:', error);
    return [];
  }
};

export const updatePaymentAccount = async (accountId: string, updates: Partial<PaymentAccount>): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from('app_b228d5f965_payment_accounts')
      .update({
        name: updates.name,
        type: updates.type,
        updated_at: new Date().toISOString()
      })
      .eq('id', accountId)
      .eq('user_id', user.id);

    return !error;
  } catch (error) {
    console.error('Error updating payment account:', error);
    return false;
  }
};

export const deletePaymentAccount = async (accountId: string): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from('app_b228d5f965_payment_accounts')
      .delete()
      .eq('id', accountId)
      .eq('user_id', user.id);

    return !error;
  } catch (error) {
    console.error('Error deleting payment account:', error);
    return false;
  }
};

// Booking Management
export const createBooking = async (booking: Omit<Booking, 'id' | 'payments'>): Promise<Booking | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('app_b228d5f965_bookings')
      .insert({
        user_id: user.id,
        hotel_id: booking.hotelId,
        guest_name: booking.guestName,
        guest_email: booking.guestEmail,
        guest_phone: booking.guestPhone,
        room_number: booking.roomNumber,
        check_in_date: booking.checkInDate,
        check_out_date: booking.checkOutDate,
        adults: booking.adults,
        children: booking.children,
        total_amount: booking.totalAmount,
        status: booking.status || 'confirmed',
        notes: booking.notes
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      hotelId: data.hotel_id,
      guestName: data.guest_name,
      guestEmail: data.guest_email,
      guestPhone: data.guest_phone,
      roomNumber: data.room_number,
      checkInDate: data.check_in_date,
      checkOutDate: data.check_out_date,
      adults: data.adults,
      children: data.children,
      totalAmount: parseFloat(data.total_amount),
      status: data.status,
      notes: data.notes,
      payments: []
    };
  } catch (error) {
    console.error('Error creating booking:', error);
    return null;
  }
};

export const getBookings = async (): Promise<Booking[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('app_b228d5f965_bookings')
      .select(`
        *,
        app_b228d5f965_payments (
          id,
          amount,
          payment_method,
          transaction_id,
          notes,
          payment_date,
          payment_account_id,
          app_b228d5f965_payment_accounts (
            name
          )
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data.map(booking => ({
      id: booking.id,
      hotelId: booking.hotel_id,
      guestName: booking.guest_name,
      guestEmail: booking.guest_email,
      guestPhone: booking.guest_phone,
      roomNumber: booking.room_number,
      checkInDate: booking.check_in_date,
      checkOutDate: booking.check_out_date,
      adults: booking.adults,
      children: booking.children,
      totalAmount: parseFloat(booking.total_amount),
      status: booking.status,
      notes: booking.notes,
      payments: booking.app_b228d5f965_payments.map((payment: any) => ({
        id: payment.id,
        amount: parseFloat(payment.amount),
        paymentMethod: payment.payment_method,
        paymentAccountId: payment.payment_account_id,
        paymentAccountName: payment.app_b228d5f965_payment_accounts?.name || '',
        transactionId: payment.transaction_id,
        notes: payment.notes,
        paymentDate: payment.payment_date
      }))
    }));
  } catch (error) {
    console.error('Error fetching bookings:', error);
    return [];
  }
};

export const updateBooking = async (bookingId: string, updates: Partial<Booking>): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from('app_b228d5f965_bookings')
      .update({
        guest_name: updates.guestName,
        guest_email: updates.guestEmail,
        guest_phone: updates.guestPhone,
        room_number: updates.roomNumber,
        check_in_date: updates.checkInDate,
        check_out_date: updates.checkOutDate,
        adults: updates.adults,
        children: updates.children,
        total_amount: updates.totalAmount,
        status: updates.status,
        notes: updates.notes,
        updated_at: new Date().toISOString()
      })
      .eq('id', bookingId)
      .eq('user_id', user.id);

    return !error;
  } catch (error) {
    console.error('Error updating booking:', error);
    return false;
  }
};

export const deleteBooking = async (bookingId: string): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { error } = await supabase
      .from('app_b228d5f965_bookings')
      .delete()
      .eq('id', bookingId)
      .eq('user_id', user.id);

    return !error;
  } catch (error) {
    console.error('Error deleting booking:', error);
    return false;
  }
};

// Payment Management
export const createPayment = async (payment: Omit<Payment, 'id'>): Promise<Payment | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    // Start a transaction to update payment account balance
    const { data, error } = await supabase
      .from('app_b228d5f965_payments')
      .insert({
        user_id: user.id,
        booking_id: payment.bookingId,
        payment_account_id: payment.paymentAccountId,
        amount: payment.amount,
        payment_method: payment.paymentMethod,
        transaction_id: payment.transactionId,
        notes: payment.notes,
        payment_date: payment.paymentDate || new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    // Update payment account balance
    const { error: balanceError } = await supabase.rpc('increment_account_balance', {
      account_id: payment.paymentAccountId,
      amount: payment.amount
    });

    if (balanceError) console.error('Error updating account balance:', balanceError);

    return {
      id: data.id,
      bookingId: data.booking_id,
      paymentAccountId: data.payment_account_id,
      amount: parseFloat(data.amount),
      paymentMethod: data.payment_method,
      transactionId: data.transaction_id,
      notes: data.notes,
      paymentDate: data.payment_date
    };
  } catch (error) {
    console.error('Error creating payment:', error);
    return null;
  }
};

export const getPayments = async (): Promise<Payment[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('app_b228d5f965_payments')
      .select('*')
      .eq('user_id', user.id)
      .order('payment_date', { ascending: false });

    if (error) throw error;

    return data.map(payment => ({
      id: payment.id,
      bookingId: payment.booking_id,
      paymentAccountId: payment.payment_account_id,
      amount: parseFloat(payment.amount),
      paymentMethod: payment.payment_method,
      transactionId: payment.transaction_id,
      notes: payment.notes,
      paymentDate: payment.payment_date
    }));
  } catch (error) {
    console.error('Error fetching payments:', error);
    return [];
  }
};

// Expense Management
export const createExpense = async (expense: Omit<Expense, 'id'>): Promise<Expense | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('app_b228d5f965_expenses')
      .insert({
        user_id: user.id,
        hotel_id: expense.hotelId,
        payment_account_id: expense.paymentAccountId,
        category: expense.category,
        description: expense.description,
        amount: expense.amount,
        expense_date: expense.expenseDate,
        notes: expense.notes
      })
      .select()
      .single();

    if (error) throw error;

    // Update payment account balance (subtract expense)
    const { error: balanceError } = await supabase.rpc('increment_account_balance', {
      account_id: expense.paymentAccountId,
      amount: -expense.amount
    });

    if (balanceError) console.error('Error updating account balance:', balanceError);

    return {
      id: data.id,
      hotelId: data.hotel_id,
      paymentAccountId: data.payment_account_id,
      category: data.category,
      description: data.description,
      amount: parseFloat(data.amount),
      expenseDate: data.expense_date,
      notes: data.notes
    };
  } catch (error) {
    console.error('Error creating expense:', error);
    return null;
  }
};

export const getExpenses = async (): Promise<Expense[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('app_b228d5f965_expenses')
      .select('*')
      .eq('user_id', user.id)
      .order('expense_date', { ascending: false });

    if (error) throw error;

    return data.map(expense => ({
      id: expense.id,
      hotelId: expense.hotel_id,
      paymentAccountId: expense.payment_account_id,
      category: expense.category,
      description: expense.description,
      amount: parseFloat(expense.amount),
      expenseDate: expense.expense_date,
      notes: expense.notes
    }));
  } catch (error) {
    console.error('Error fetching expenses:', error);
    return [];
  }
};