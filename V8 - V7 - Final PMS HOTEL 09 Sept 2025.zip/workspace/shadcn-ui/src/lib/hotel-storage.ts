import { Hotel, PaymentAccount, Settings } from './types';
import * as db from './database';

const CURRENT_HOTEL_KEY = 'currentHotel';
const SETTINGS_KEY = 'settings';

// Settings Storage (keep local for now)
export const settingsStorage = {
  get: (): Settings => {
    const stored = localStorage.getItem(SETTINGS_KEY);
    return stored ? JSON.parse(stored) : {
      currentHotelId: '',
      currency: 'USD',
      timezone: 'America/New_York',
      dateFormat: 'MM/DD/YYYY',
      language: 'en'
    };
  },
  
  save: (settings: Settings): void => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }
};

// Hotel Management - Now using Supabase
export const getHotels = async (): Promise<Hotel[]> => {
  return await db.getHotels();
};

export const saveHotels = async (hotels: Hotel[]): Promise<void> => {
  // This function is no longer needed as we save individually
  console.warn('saveHotels is deprecated, use individual create/update functions');
};

export const addHotel = async (hotel: Omit<Hotel, 'id' | 'paymentAccounts'>): Promise<Hotel | null> => {
  const newHotel = await db.createHotel(hotel);
  
  if (newHotel) {
    // Set as current hotel if it's the first one
    const hotels = await getHotels();
    if (hotels.length === 1) {
      setCurrentHotel(newHotel.id);
    }
  }
  
  return newHotel;
};

export const updateHotel = async (hotelId: string, updates: Partial<Hotel>): Promise<void> => {
  await db.updateHotel(hotelId, updates);
};

export const deleteHotel = async (hotelId: string): Promise<void> => {
  await db.deleteHotel(hotelId);
  
  // Clear current hotel if it was deleted
  const currentHotelId = getCurrentHotelId();
  if (currentHotelId === hotelId) {
    const hotels = await getHotels();
    if (hotels.length > 0) {
      setCurrentHotel(hotels[0].id);
    } else {
      localStorage.removeItem(CURRENT_HOTEL_KEY);
      const settings = settingsStorage.get();
      settings.currentHotelId = '';
      settingsStorage.save(settings);
    }
  }
};

// Hotel Storage for compatibility
export const hotelStorage = {
  getAll: getHotels,
  save: async (hotel: Hotel) => {
    if (hotel.id) {
      await updateHotel(hotel.id, hotel);
    } else {
      await addHotel(hotel);
    }
  },
  delete: deleteHotel
};

// Payment Account Management - Now using Supabase
export const getPaymentAccounts = async (hotelId: string): Promise<PaymentAccount[]> => {
  return await db.getPaymentAccounts(hotelId);
};

export const addPaymentAccount = async (hotelId: string, account: Omit<PaymentAccount, 'id' | 'hotelId'>): Promise<void> => {
  await db.createPaymentAccount(hotelId, account);
};

export const updatePaymentAccount = async (hotelId: string, accountId: string, updates: Partial<PaymentAccount>): Promise<void> => {
  await db.updatePaymentAccount(accountId, updates);
};

export const deletePaymentAccount = async (hotelId: string, accountId: string): Promise<void> => {
  await db.deletePaymentAccount(accountId);
};

export const updatePaymentAccountBalance = async (hotelId: string, accountId: string, amount: number): Promise<void> => {
  // This is now handled automatically in the database when creating payments/expenses
  console.warn('updatePaymentAccountBalance is deprecated, balances are updated automatically');
};

// Current Hotel Management (keep local for session)
export const getCurrentHotelId = (): string | null => {
  const settings = settingsStorage.get();
  return settings.currentHotelId || localStorage.getItem(CURRENT_HOTEL_KEY);
};

export const getCurrentHotel = async (): Promise<Hotel | null> => {
  const currentId = getCurrentHotelId();
  if (!currentId) {
    const hotels = await getHotels();
    return hotels[0] || null;
  }
  
  const hotels = await getHotels();
  return hotels.find(h => h.id === currentId) || null;
};

export const setCurrentHotel = (hotelId: string): void => {
  localStorage.setItem(CURRENT_HOTEL_KEY, hotelId);
  const settings = settingsStorage.get();
  settings.currentHotelId = hotelId;
  settingsStorage.save(settings);
};

// Initialize default hotel data
export const initializeHotelData = async (): Promise<void> => {
  const hotels = await getHotels();
  
  if (hotels.length === 0) {
    // Create a default hotel
    const defaultHotel = await addHotel({
      name: 'Sample Hotel',
      address: '123 Main Street, City',
      phone: '+1234567890',
      email: 'info@samplehotel.com',
      currency: 'INR',
      timezone: 'Asia/Kolkata',
      totalRooms: 50
    });
    
    if (defaultHotel) {
      setCurrentHotel(defaultHotel.id);
    }
  }
};

// Booking Management - Now using Supabase
export const getBookings = async () => {
  return await db.getBookings();
};

export const saveBookings = async (bookings: any[]): Promise<void> => {
  console.warn('saveBookings is deprecated, use individual create/update functions');
};

export const addBooking = async (booking: any) => {
  return await db.createBooking(booking);
};

export const updateBooking = async (bookingId: string, updates: any): Promise<void> => {
  await db.updateBooking(bookingId, updates);
};

export const deleteBooking = async (bookingId: string): Promise<void> => {
  await db.deleteBooking(bookingId);
};

// Payment Management - Now using Supabase
export const getPayments = async () => {
  return await db.getPayments();
};

export const savePayments = async (payments: any[]): Promise<void> => {
  console.warn('savePayments is deprecated, use individual create/update functions');
};

export const addPayment = async (payment: any) => {
  return await db.createPayment(payment);
};

export const updatePayment = async (paymentId: string, updates: any): Promise<void> => {
  console.warn('updatePayment not implemented yet');
};

export const deletePayment = async (paymentId: string): Promise<void> => {
  console.warn('deletePayment not implemented yet');
};

// Expense Management - Now using Supabase
export const getExpenses = async () => {
  return await db.getExpenses();
};

export const saveExpenses = async (expenses: any[]): Promise<void> => {
  console.warn('saveExpenses is deprecated, use individual create/update functions');
};

export const addExpense = async (expense: any) => {
  return await db.createExpense(expense);
};

export const updateExpense = async (expenseId: string, updates: any): Promise<void> => {
  console.warn('updateExpense not implemented yet');
};

export const deleteExpense = async (expenseId: string): Promise<void> => {
  console.warn('deleteExpense not implemented yet');
};