# Hotel PMS Solution - MVP Implementation Plan

## Core Features
1. **Booking Management** - Create, view, update, delete bookings
2. **Payments Management** - Handle multiple payments per booking
3. **Expense Management** - Track hotel operational expenses
4. **Dashboard** - Overview of key metrics and recent activities

## File Structure (8 files max)

### 1. src/pages/Index.tsx
- Main dashboard with key metrics
- Recent bookings, payments, expenses overview
- Navigation to different modules

### 2. src/components/BookingManager.tsx
- Booking list with search/filter
- Add/Edit booking form
- Booking details view
- Status management (pending, confirmed, checked-in, checked-out, cancelled)

### 3. src/components/PaymentManager.tsx
- Payment list linked to bookings
- Add payment form
- Payment status tracking
- Multiple payments per booking support

### 4. src/components/ExpenseManager.tsx
- Expense list with categories
- Add/Edit expense form
- Expense categories (maintenance, supplies, utilities, etc.)

### 5. src/lib/types.ts
- TypeScript interfaces for Booking, Payment, Expense
- Status enums and validation schemas

### 6. src/lib/storage.ts
- Local storage management
- CRUD operations for all entities
- Data persistence and retrieval

### 7. src/lib/utils-pms.ts
- Business logic utilities
- Calculations (total revenue, outstanding payments)
- Date formatting and validation helpers

### 8. src/components/ui/data-table.tsx
- Reusable data table component
- Sorting, filtering, pagination
- Used across all modules

## Data Models

### Booking
- id, guestName, email, phone, roomNumber, roomType
- checkInDate, checkOutDate, totalAmount, status
- createdAt, updatedAt, notes

### Payment
- id, bookingId, amount, paymentMethod, status
- paymentDate, reference, notes

### Expense
- id, category, description, amount, date
- vendor, reference, createdAt

## Key Features
- Responsive design with mobile support
- Real-time calculations and updates
- Input validation and error handling
- Search and filter capabilities
- Export functionality for reports
- Minimalistic UI focused on efficiency